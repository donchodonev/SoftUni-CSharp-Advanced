﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<Car> cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] carParam = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string carModel = carParam[0];
                double fuelAmount = double.Parse(carParam[1]);
                double fuelConsumption = double.Parse(carParam[2]);

                cars.Add(new Car(carModel, fuelAmount,fuelConsumption));
            }

            string command = Console.ReadLine();

            while (command != "End")
            {
                string[] commandArgs = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string model = commandArgs[1];
                double distanceToTravel = double.Parse(commandArgs[2]);


                Car.Drive(cars.Find(car => car.Model == model), distanceToTravel);

                command = Console.ReadLine();
            }

            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:F2} {car.TravelledDistance}");
            }
        }
    }
}