﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class Car
    {
        public Car(string model, Engine engine, double weight, string color)
        {
            Model = model;
            Engine = engine;
            Weight = weight;
            Color = color;
        }

        public string Model { get; set; }
        public Engine Engine { get; set; }
        public double Weight { get; set; }
        public string Color { get; set; }


        public override string ToString()
        {
            string engineDisplacement = Engine.Displacement.ToString();
            string engineEfficiency = Engine.Efficiency;
            string carWeight = Weight.ToString();
            string carColor = Color;

            string result = string.Empty;

            if (engineDisplacement == "0")
            {
                engineDisplacement = "n/a";
            }
            if (engineEfficiency == null)
            {
                engineEfficiency = "n/a";
            }
            if (carWeight == "0")
            {
                carWeight = "n/a";
            }
            if (carColor == null)
            {
                carColor = "n/a";
            }

            result = $@"{Model}:
  {Engine.Model}:
    Power: {Engine.Power}
    Displacement: {engineDisplacement}
    Efficiency: {engineEfficiency}
  Weight: {carWeight}
  Color: {carColor}
";

            return result;
        }
    }
}
