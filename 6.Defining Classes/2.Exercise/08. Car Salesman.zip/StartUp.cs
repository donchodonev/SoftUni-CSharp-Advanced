﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int engineCount = int.Parse(Console.ReadLine());

            Engine[] engines = new Engine[engineCount];

            for (int i = 0; i < engineCount; i++)
            {
                string[] engineParams = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string model = engineParams[0];
                int power = int.Parse(engineParams[1]);
                double displacement = 0;
                string efficiency = null;

                for (int v = 2; v < engineParams.Length; v++)
                {
                    if (v == 2)
                    {
                        if (double.TryParse(engineParams[v], out displacement))
                        {
                            continue;
                        }
                    }
                    efficiency = engineParams[v];
                }

                engines[i] = new Engine(model, power, displacement, efficiency);
            }

            int carCount = int.Parse(Console.ReadLine());

            Car[] cars = new Car[carCount];

            for (int j = 0; j < carCount; j++)
            {
                string[] carParams = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string model = carParams[0];
                string engineName = carParams[1];
                double weight = 0;
                string color = null;

                for (int b = 2; b < carParams.Length; b++)
                {
                    if (b == 2)
                    {
                        if (double.TryParse(carParams[b], out weight))
                        {
                            continue;
                        }
                    }
                    color = carParams[b];
                }

                Engine thisEngine = engines.First(engine => engine.Model == engineName);

                cars[j] = new Car(model, thisEngine, weight, color);
            }

            foreach (var car in cars)
            {
                Console.Write(car);
            }
        }
    }
}
