﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        public List<Person> FamilyMembers { get; set; } = new List<Person>();

        public void AddMember(Person person)
        {
            FamilyMembers.Add(person);
        }
        public Person GetOldestMember()
        {
            int oldestAge = int.MinValue;
            string oldestName = string.Empty;

            foreach (var member in FamilyMembers)
            {
                if (member.Age > oldestAge)
                {
                    oldestAge = member.Age;
                    oldestName = member.Name;
                }
            }

            return new Person(oldestName, oldestAge);
        }
    }
}
