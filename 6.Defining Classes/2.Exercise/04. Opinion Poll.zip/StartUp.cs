﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<Person> people = new List<Person>();

            for (int i = 0; i < n; i++)
            {
                string[] personParams = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string name = personParams[0];
                int age = int.Parse(personParams[1]);

                people.Add(new Person(name, age));
            }

            foreach (var person in people
                .Where(person => person.Age > 30)
                .OrderBy(person => person.Name))
            {
                Console.WriteLine($"{person.Name} - {person.Age}");
            }
        }
    }
}
