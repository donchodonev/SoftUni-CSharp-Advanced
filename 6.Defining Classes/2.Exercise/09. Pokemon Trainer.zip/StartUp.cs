﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Trainer> trainers = new List<Trainer>();

            string command = Console.ReadLine();

            while (command != "Tournament")
            {
                string[] arguments = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string trainerName = arguments[0];
                string pokemonName = arguments[1];
                string pokemonElement = arguments[2];
                int pokemonHealth = int.Parse(arguments[3]);

                if (trainers.FirstOrDefault(trainer => trainer.Name == trainerName) != null)
                {
                    trainers
                        .First(trainer => trainer.Name == trainerName).Pokemons
                        .Add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));
                }
                else
                {
                    trainers.Add(new Trainer(trainerName, new Pokemon(pokemonName, pokemonElement, pokemonHealth)));
                }

                command = Console.ReadLine();
            }

            command = Console.ReadLine();

            while (command != "End")
            {
                foreach (var trainer in trainers)
                {
                    if (trainer.Pokemons.Any(pokemon => pokemon.Element == command))
                    {
                        trainer.BadgesCount++;
                    }
                    else
                    {
                        trainer.PokemonHealthMinus10();
                        trainer.PokemonCheckHealth();
                    }
                }
                command = Console.ReadLine();
            }

            foreach (var trainer in trainers.OrderByDescending(trainer => trainer.BadgesCount))
            {
                Console.WriteLine($"{trainer.Name} {trainer.BadgesCount} {trainer.Pokemons.Count}");
            }
        }
    }
}
