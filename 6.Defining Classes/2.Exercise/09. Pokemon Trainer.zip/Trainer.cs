﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Trainer
    {
        public Trainer(string name, Pokemon pokemon)
        {
            BadgesCount = 0;
            Name = name;
            Pokemons.Add(pokemon);
        }

        public string Name { get; set; }
        public int BadgesCount { get; set; }
        public List<Pokemon> Pokemons { get; set; } = new List<Pokemon>();

        public void PokemonHealthMinus10()
        {
            foreach (var pokemon in Pokemons)
            {
                pokemon.Health -= 10;
            }
        }
        public List<Pokemon> PokemonCheckHealth() 
        {
            return Pokemons = Pokemons
                .Except(Pokemons.Where(pokemon => pokemon.Health <= 0))
                .ToList();
        }
    }
}
