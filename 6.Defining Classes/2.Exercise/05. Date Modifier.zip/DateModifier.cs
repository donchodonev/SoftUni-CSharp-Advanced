﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public static class DateModifier
    {
        public static void DifferenceInDays(string firstDate, string secondDate)
        {
            DateTime FirstDate = DateTime.Parse(firstDate);
            DateTime SecondDate = DateTime.Parse(secondDate);
            int DifferenceInDates = int.Parse(FirstDate.Subtract(SecondDate).Days.ToString());

            Console.WriteLine(Math.Abs(DifferenceInDates));
        }
    }
}
