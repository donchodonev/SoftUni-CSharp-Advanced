﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Family family = new Family();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] memberParams = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                family.AddMember(new Person(memberParams[0],int.Parse(memberParams[1])));
            }

            Console.WriteLine($"{family.GetOldestMember().Name} {family.GetOldestMember().Age}"); 
        }
    }
}
