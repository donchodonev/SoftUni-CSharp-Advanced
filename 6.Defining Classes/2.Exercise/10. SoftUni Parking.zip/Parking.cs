﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftUniParking
{
    public class Parking
    {
        public Parking(int capacity)
        {
            this.capacity = capacity;

            Cars = new List<Car>(capacity);
        }

        public List<Car> Cars { get; set; }

        private int capacity;

        public int Count => Cars.Count;

        public string AddCar(Car carToAdd) 
        {
            if (Cars.Any(car => car.RegistrationNumber == carToAdd.RegistrationNumber))
            {
                return "Car with that registration number, already exists!";
            }
            else if (Count >= this.capacity)
            {
                return "Parking is full!";
            }
            else
            {
                Cars.Add(carToAdd);
                return $"Successfully added new car {carToAdd.Make} {carToAdd.RegistrationNumber}";
            }
        }
        public string RemoveCar(string regNumber)
        {
            if (Cars.FirstOrDefault(car => car.RegistrationNumber == regNumber) == null)
            {
                return "Car with that registration number, doesn't exist!";
            }
            else
            {
                Cars.Remove(Cars.First(car => car.RegistrationNumber == regNumber));
                return $"Successfully removed {regNumber}";
            }
        }
        public Car GetCar(string regNumber)
        {
            return Cars.First(car => car.RegistrationNumber == regNumber);
        }

        public void RemoveSetOfRegistrationNumber(List<string> registrationNumbers)
        {
            foreach (var regNum in registrationNumbers)
            {
                if (Cars.FirstOrDefault(car => car.RegistrationNumber == regNum) != null)
                {
                    Cars.Remove(Cars.First(car => car.RegistrationNumber == regNum));
                }
            }
        }
    }
}
