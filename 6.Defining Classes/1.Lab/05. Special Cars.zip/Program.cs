﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string firstCommand = Console.ReadLine();

            List<Tire[]> tires = new List<Tire[]>();

            List<Engine> engines = new List<Engine>();

            List<Car> cars = new List<Car>();

            int tireArrayIndex = 0;
            int tireArrayTireIndex = 0;

            while (firstCommand != "No more tires")
            {
                string[] tireParam = firstCommand.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                tires.Add(new Tire[4]);

                for (int i = 0; i < tireParam.Length; i += 2)
                {
                    tires[tireArrayIndex][tireArrayTireIndex] = new Tire();
                    tires[tireArrayIndex][tireArrayTireIndex].Year = int.Parse(tireParam[i]);
                    tires[tireArrayIndex][tireArrayTireIndex].Pressure = double.Parse(tireParam[i + 1]);
                    tireArrayTireIndex++;
                }
                tireArrayIndex++;
                tireArrayTireIndex = 0;

                firstCommand = Console.ReadLine();
            }

            string secondCommand = Console.ReadLine();

            while (secondCommand != "Engines done")
            {
                string[] engineParam = secondCommand.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                int enginePower = int.Parse(engineParam[0]);

                double engineCapacity = double.Parse(engineParam[1]);

                engines.Add(new Engine(enginePower, engineCapacity));

                secondCommand = Console.ReadLine();
            }

            string thirdCommand = Console.ReadLine();

            while (thirdCommand != "Show special")
            {
                string[] carParams = thirdCommand.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string make = carParams[0];
                string model = carParams[1];
                int year = int.Parse(carParams[2]);
                double fuelQuantity = double.Parse(carParams[3]);
                double fuelConsumption = double.Parse(carParams[4]);
                int engineIndex = int.Parse(carParams[5]);
                int tireIndex = int.Parse(carParams[6]);

                cars.Add(new Car(make, model, year, fuelQuantity, fuelConsumption, engines[engineIndex], tires[tireIndex]));

                thirdCommand = Console.ReadLine();
            }

            foreach (var car in cars
                .Where(car => car.Year >= 2007)
                .Where(car => car.Engine.HorsePower > 330)
                .Where(car => car.Tires.Select(x => x.Pressure).Sum() >= 9 && car.Tires.Select(x => x.Pressure).Sum() <= 10))
            {
                car.Drive(20.0);

                Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}\nHorsePowers: {car.Engine.HorsePower}\nFuelQuantity: {car.FuelQuantity}");
            }
        }
    }
}
